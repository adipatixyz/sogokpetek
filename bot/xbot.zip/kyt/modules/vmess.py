from kyt import *
import subprocess
import time
import datetime as DT
from telethon import events, Button
import json
import base64
import re

# CREATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond("Username : ")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

        async with bot.conversation(chat) as ip:
            await event.respond("Limit Ip : ")
            ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = (await ip).raw_text

        async with bot.conversation(chat) as quota:
            await event.respond("Limit Quota : ")
            quota = quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota = (await quota).raw_text

        async with bot.conversation(chat) as exp:
            await event.respond("Choose Expired Day", buttons=[
                [Button.inline("3 Day", "3"), Button.inline("7 Day", "7")],
                [Button.inline("30 Day", "30"), Button.inline("60 Day", "60")]
            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")

        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(0)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")

        cmd = f'printf "%s\n" "{user}" "{ip}" "{quota}" "{exp}" | addws-bot'
        try:
            output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode()
        except subprocess.CalledProcessError as e:
            output = e.output.decode()

        if "Username sudah terpakai" in output:
            await event.respond("Username sudah terpakai.")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            b = [x.group() for x in re.finditer("vmess://(.*)", output)]
            print(b)
            z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
            z = json.loads(z)
            z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
            z1 = json.loads(z1)
            msg = f"""
`☉————————————————————————☉`
`🧿Create Vmess Account Success🧿`
`☉————————————————————————☉`
`Subdomain :` `{z["add"]}`
`Hostname  :` `{z["ps"]}`
`Max Login :` `{ip} User`
`Max Quota :` `{quota} GB`
`☉————————————————————————☉`
🧿`Expired {later}`🧿
`☉————————————————————————☉`
`Port TLS  :` `443, 53`
`Port nTLS :` `80, 8080, 8081-9999`
`Port GRPC :` `443`
`User UUID :` `{z["id"]}`
`Info Path :` `/vmess`
`☉————————————————————————☉`
Link TLS 🧿`{b[0].strip("'").replace(" ", "")}`🧿
`☉————————————————————————☉`
Link NTLS 🧿`{b[1].strip("'").replace(" ", "")}`🧿
`☉————————————————————————☉`
Link GRPC 🧿`{b[2].strip("'")}`🧿
`☉————————————————————————☉`
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Minutes**", buttons=[
                [Button.inline("10 Menit", "10"), Button.inline("15 Menit", "15")],
                [Button.inline("30 Menit", "30"), Button.inline("60 Menit", "60")]
            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")

        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(3)
        await event.edit("`Processing Create Trial Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(2)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(3)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(2)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")

        cmd = f'printf "%s\n" "{exp}" | bot-trialws'
        try:
            output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode()
        except subprocess.CalledProcessError as e:
            output = e.output.decode()

        b = [x.group() for x in re.finditer("vmess://(.*)", output)]
        if len(b) < 2:
            await event.respond("Gagal membuat akun VMess: URL VMess tidak ditemukan.")
            return

        today = DT.datetime.now()
        later = today + DT.timedelta(minutes=int(exp))

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)
        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
`☉————————————————————————☉`
`🧿Create Vmess Trial Account Success🧿`
`☉————————————————————————☉`
`Subdomain :` `{z["add"]}`
`Hostname  :` `{z["ps"]}`
`Max Login :` `Unlimited`
`Max Quota :` `Unlimited`
`☉————————————————————————☉`
🧿`Expired {exp} Menit`🧿
`☉————————————————————————☉`
`Port TLS  :` `443, 53`
`Port nTLS :` `80, 8080`
`Port GRPC :` `443`
`User UUID :` `{z["id"]}`
`Info Path :` `/vmess`
`☉————————————————————————☉`
Link TLS 🧿`{b[0].strip("'").replace(" ", "")}`🧿
`☉————————————————————————☉`
Link NTLS 🧿`{b[1].strip("'").replace(" ", "")}`🧿
`☉————————————————————————☉`
Link GRPC 🧿`{b[2].strip("'")}`🧿
`☉————————————————————————☉`
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("TRIAL VMESS", "trial-vmess"), Button.inline("CREATE VMESS", "create-vmess")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█

๑۞๑ @Gemilangkinasih
━━━━━━━━━━━━━━━━━━━━━━ 
MENU V2RAY VMESS
━━━━━━━━━━━━━━━━━━━━━━
`♔ Service :` `V2RAY VMESS`
`♔ Domain  :` `{DOMAIN}`
`♔ ISP     :` `{z["isp"]}`
`♔ Region  :` `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vmess_(event)
    else:
        await event.answer("Access Denied", alert=True)
